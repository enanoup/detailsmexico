import { Component, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Producto } from '../interfaces/producto-interface';
import { ShoppingCartService } from '../../services/shopping-cart.service';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { FormsService } from '../../services/forms.service';
import { Subscription } from 'rxjs';
import swal from 'sweetalert2';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit, OnDestroy {

  @ViewChild('Total', {static: false}) total: ElementRef;

  productosCarrito: Producto[] = [];
  subTotal = 0;
  descuento = 0;
  cantidadChange = 0;
  ahorroTotal = 0;
  iva = 1.16;

  nombre: string;
  email: string;
  telefono: string;

  checkoutForm: any;
  subscription: Subscription;

  constructor(private route: ActivatedRoute,
              private shoppingService: ShoppingCartService,
              private formBuilder: FormBuilder,
              private formService: FormsService) {

                this.checkoutForm = this.formBuilder.group({
                  nombre: new FormControl(this.nombre, [Validators.required, Validators.minLength(4)]),
                  email: new FormControl(this.email, [Validators.required, Validators.email]),
                  telefono: new FormControl(this.telefono),
                  total: new FormControl(this.total),
                });
  }

  // Este va a sumar el subtotal antes del descuento
  sumaSubtotal() {
      let totalParcial = 0;
      let totalSinDescuento = 0;

      for ( const producto of this.productosCarrito) {
        totalParcial += producto.sumaTotal;
        totalSinDescuento += producto.sumaSinDescuento;
      }

      this.subTotal = Number.parseFloat((totalParcial).toFixed(2));
      this.ahorroTotal = Number.parseFloat((totalSinDescuento - totalParcial).toFixed(2));
   }

   updateCart( event: any, producto: Producto ) {

      let value: boolean;

    // Validamos las existencias del producto
      if ( this.validarExistencias(event.target.value, producto)) {
        this.cantidadChange = event.target.value;
        this.shoppingService.grabarShoppingCart( producto, this.cantidadChange );
        this.checkoutForm.reset();
        // En lo que se graba el carrito otra vez me espero para que la suma tome los cambios
        setTimeout(() => {
          this.sumaSubtotal();
        }, 500);
        value = true;
      }
   }

   quitarProducto(idProducto: number) {
      this.shoppingService.borrarItemDelShoppingCart(idProducto);
      this.obtenerShoppingCart();
      console.log('Se borró');
   }

   private obtenerShoppingCart() {
    this.shoppingService.obtenerShoppingCart().subscribe( data => {
      this.productosCarrito = data;
    });
    this.sumaSubtotal();
    this.shoppingService.sendProductAddCart(true);
  }

  onSubmit(customerData: any) {

    // Validamos que haya productos para mandar en el Checkout
    if ( this.extraerProductos().length > 0 ) {

      this.subscription =
          this.formService.sendCheckoutForm(
            customerData.nombre, customerData.email, customerData.telefono, this.extraerProductos(), this.total.nativeElement.innerHTML)
              .subscribe( () => {
                swal.fire(`Gracias ${ customerData.nombre }`,
                'Tu solicitud ha sido recibida, en breve estaremos en contacto contigo',
                'success');
                this.checkoutForm.reset();
              });

      } else {
        swal.fire(`Lo Sentimos ${ customerData.nombre }`,
        'No existe ningun artículo en el carrito',
        'error');
      }
    }

    // Valida existencias en los cambios de cantidad en checkout
    validarExistencias( value: any, producto: Producto): boolean {

      if ( value <= producto.cantidad ) {
        return true;
      } else {
        return false;
      }
    }

    extraerProductos(): Producto[] {
      return this.productosCarrito;
    }

    ngOnInit() {

      this.productosCarrito = this.route.snapshot.data.carrito;
      if ( this.productosCarrito.length > 0) {
        this.sumaSubtotal();
      }

    }

    ngOnDestroy() {
      if ( this.subscription ) {
        this.subscription.unsubscribe();
      }
    }

}
