import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { Producto } from '../pages/interfaces/producto-interface';
import { ProductoCarrito } from '../pages/interfaces/producto-carrito';


@Injectable({
  providedIn: 'root'
})
export class FormsService {

  constructor(private http: HttpClient) { }

  sendCheckoutForm(nombre: string, email: string, telefono: string, productos: Producto[], totalConIva: string): Observable<any> {

    // Convertimos el arregño de productos a un string
    const prodCarrito = JSON.stringify(this.convertProductoToProductoCarrito(productos));

    return this.http.get('https://detailsmexico.com/mail/envio-checkout.php',
        { responseType: 'text', params: { nombre, email, telefono, prodCarrito, totalConIva } });

  }

  uploadLogo(file: File): Promise<any> {
    // tslint:disable-next-line: no-debugger
    // debugger;
    const formData: FormData = new FormData();

    return new Promise( resolve => {

      const headers = new HttpHeaders({
        responseType: 'text',
        'Content-Type': 'application/x-www-form-urlencoded'
        });
      const options = { headers };

      formData.append('logo', file, file.name);
      this.http.post('https://detailsmexico.com/uploads/file-upload.php', formData,
        { responseType: 'text'})
        .subscribe( resp => {
         resolve(resp);
      });
    });

  }

  sendContactForm( nombre: string, apellido: string, email: string, telefono: string, mensaje: string): Observable<any> {

    return this.http.get('https://detailsmexico.com/mail/envio-contacto.php',
        {responseType: 'text', params: { nombre, apellido, email, telefono, mensaje }});
  }

  sendEmailMarketingForm(email: string ) {
    return this.http.get('https://detailsmexico.com/mail/envio-marketing.php',
        {responseType: 'text', params: { email }});
  }

  convertProductoToProductoCarrito(productos: Producto[]): ProductoCarrito[] {

    const allProductosCarrito: ProductoCarrito[] = [];

    if ( productos.length > 0 ) {

      productos.forEach( producto => {

        const productoCarrito: ProductoCarrito = {
          sku: '',
          proveedor: '',
          nombre: '',
          url: '',
          solicitud: 0,
          precioUnitario: 0,
          precioDescuento: 0,
          total: 0
        };

        productoCarrito.sku = producto.sku;
        productoCarrito.nombre = producto.nombre;
        productoCarrito.proveedor = producto.proveedor;
        productoCarrito.url = producto.urls[0].url;
        productoCarrito.solicitud = producto.solicitud;
        productoCarrito.precioUnitario = producto.precioActual;
        productoCarrito.precioDescuento = producto.precioConDescuento;
        productoCarrito.total = producto.sumaTotal;

        allProductosCarrito.push(productoCarrito);

      });

    } else {
      console.log( 'No hay productos en el carrito ');
    }

    return allProductosCarrito;
  }

}
