export interface ProductoCarrito {

    sku: string;
    proveedor: string;
    nombre: string;
    url: string;
    solicitud: number;
    precioUnitario: number;
    precioDescuento: number;
    total: number;

}
