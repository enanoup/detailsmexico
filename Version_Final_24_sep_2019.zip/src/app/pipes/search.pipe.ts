import { Pipe, PipeTransform } from '@angular/core';
import { ProductoService } from '../services/producto.service';

@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {

  constructor( private productoService: ProductoService ) {}

  transform(value: any, args: any): any[] {

    const resultProductos = [];
    args = this.filtrar_acentos( args );

    for (const producto of value) {

      const nombre = this.filtrar_acentos(producto.nombre);
      const descripcion = this.filtrar_acentos(producto.descripcion);
      const sku = this.filtrar_acentos(producto.sku);

      if (nombre.indexOf(args) > -1 ||
          descripcion.indexOf(args) > -1 ||
            sku.indexOf(args) > -1 ) {

        resultProductos.push(producto);

      }
    }

    this.productoService.setPipeResults(resultProductos.length);

    return resultProductos;
  }

  filtrar_acentos(input: any) {

    const acentos =  'ÃÀÁÄÂÈÉËÊÌÍÏÎÒÓÖÔÙÚÜÛãàáäâèéëêìíïîòóöôùúüûÑñÇç';
    const original = 'AAAAAEEEEIIIIOOOOUUUUaaaaaeeeeiiiioooouuuunncc';

    for (let i = 0; i < acentos.length; i++) {
        input = input.replace(acentos.charAt(i), original.charAt(i)).toLowerCase();
    }

    return input;
  }

}
