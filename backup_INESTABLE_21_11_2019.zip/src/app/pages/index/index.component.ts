import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Producto } from '../interfaces/producto-interface';
import { PromolineProductSingle } from '../interfaces/promoline-interface';
import { InnovationProduct } from '../interfaces/innovation-interface';
import { ProductoService } from '../../services/producto.service';
import { OwlOptions } from 'ngx-owl-carousel-o';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { FormsService } from '../../services/forms.service';
import { Subscription } from 'rxjs';
import swal from 'sweetalert2';

let $ = (window as any)['jQuery'];

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})

export class IndexComponent implements OnInit, AfterViewInit {

  productosNuevos: Producto[] = [];
  productosBestSeller: Producto[] = [];
  promolineProducto: PromolineProductSingle;

  innovationProducts: InnovationProduct[] = [];
  detailsProducts: Producto[] = [];
  bestSellerCarouselOptions: OwlOptions =  {};
  form: any;
  email: string;

  subscripcion: Subscription;

  constructor(private productoService: ProductoService, private formBuilder: FormBuilder,
              private formService: FormsService) {

    this.form = this.formBuilder.group({
      email: new FormControl(this.email, [Validators.required, Validators.email]),
    });
   }

  ngAfterViewInit() {

    setTimeout(() => {

      $('.furniture--4').owlCarousel({
        loop: true,
        margin: 0,
        nav: true,
        autoplay: true,
        autoplayTimeout: 3000,
        items: 4,
        navText: ['<i class="zmdi zmdi-chevron-left"></i>', '<i class="zmdi zmdi-chevron-right"></i>' ],
        dots: false,
        lazyLoad: true,
        responsive: {
            0: {
              items: 1
            },
            576: {
              items: 2
            },
            768: {
              items: 3
            },
            992: {
              items: 4
            },
            1920: {
              items: 4
            }
        }
      });

      $('.furniture--10').owlCarousel({
        loop: true,
        margin: 0,
        nav: true,
        autoplay: true,
        autoplayTimeout: 3000,
        items: 4,
        navText: ['<i class="zmdi zmdi-chevron-left"></i>', '<i class="zmdi zmdi-chevron-right"></i>' ],
        dots: false,
        lazyLoad: true,
        responsive: {
            0: {
              items: 1
            },
            576: {
              items: 2
            },
            768: {
              items: 3
            },
            992: {
              items: 4
            },
            1920: {
              items: 4
            }
        }
      });

  }, 1000);

  }
  onSubmit(customerData: any) {

    this.subscripcion = this.formService.sendEmailMarketingForm(customerData.email)
            .subscribe(() => {
                swal.fire('¡Listo!',
                'Se te notificará sobre los nuevos lanzamientos y las mejores promociones',
                'success').finally(this.form.reset());
            });
  }

  async ngOnInit() {

    // Activamos los carruseles
    this.activateSliderPrincipal();
    // Cargamos los elementos bestSeller y los nuevos productos

    await this.productoService.getNewAndBestsellerProducts().then ( productosResolve  => {

      productosResolve.forEach( producto => {
        if (producto.masVendido) {
          this.productosBestSeller.push(producto);
        } else {
          this.productosNuevos.push( producto );
        }
      });

    });
  }

  private activateSliderPrincipal() {
    // Activa el slider principal
    $('.slide__activation').owlCarousel({
      loop: true,
      margin: 0,
      nav: true,
      autoplay: true,
      autoplayTimeout: 8000,
      items: 1,
      navText: ['<i class="zmdi zmdi-chevron-left"></i>', '<i class="zmdi zmdi-chevron-right"></i>' ],
      dots: false,
      lazyLoad: true,
      responsive: {
      0: {
        items: 1
      },
      1920: {
        items: 1
      }
      }
    });
  }


}
