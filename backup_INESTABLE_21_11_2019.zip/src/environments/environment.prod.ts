export const environment = {
  production: true,
  ws_innovation_key: 'app-412454-ujd-7819',
  ws_innovation_baseUrl: 'http://www.innovation.com.mx/webservice/',

  ws_importline_key: 'ee2dfJykM4KEKE9OKjnIU89',
  ws_importline_baseUrl: 'https://importline.com.mx/api_importline/',

  ws_promoopcion_baseUrl: 'https://detailsmexico.com/ws/',
  ws_promoshop_baseUrl: 'https://detailsmexico.com/ws/'

};
