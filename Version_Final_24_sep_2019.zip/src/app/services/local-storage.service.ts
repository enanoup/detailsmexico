import { Injectable } from '@angular/core';
import { Producto } from '../pages/interfaces/producto-interface';

@Injectable({
  providedIn: 'root'
})
export class LocalStorageService {

  constructor() { }

  saveAllProducts(productos: Producto[]) {
    localStorage.setItem('allProducts', JSON.stringify(productos));
  }

  getAllProducts(): Promise<Producto[]> {
    return new Promise( resolve => {

        let productos: Producto[] = [];
        productos = JSON.parse(localStorage.getItem('allProducts'));

        resolve(productos);
    });
  }

  saveNewAndBestSellerProducts( productos: Producto[]) {
    localStorage.setItem('newAndBestseller', JSON.stringify(productos));
  }

  getNewAndBestsellerProducts(): Promise<Producto[]> {
    return new Promise ( resolve => {
      let newAndBestseller: Producto[] = [];
      newAndBestseller = JSON.parse(localStorage.getItem('newAndBestseller'));

      resolve(newAndBestseller);
    });
  }
}
