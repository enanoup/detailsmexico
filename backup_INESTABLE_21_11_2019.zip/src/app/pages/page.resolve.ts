import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { Producto } from './interfaces/producto-interface';
import { ProductoService } from '../services/producto.service';

@Injectable()
export class UserProductoResolve implements Resolve<Producto> {

  constructor(private productoService: ProductoService) {}

  async resolve(route: ActivatedRouteSnapshot) {

    let producto = null;
    producto = await this.productoService.getNewAndBestsellerBySku(route.params.sku);
    if ( !producto ) {
      producto = await this.productoService.getProductoBySKU(route.params.sku);
    }
    return producto;
  }
}
